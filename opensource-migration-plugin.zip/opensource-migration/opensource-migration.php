<?php
/**
 * Plugin Name: OpenSource.sa Migration Helper
 * Description: One-click migration helper that imports media, configures theme settings, and sets up the homepage. Go to Tools > OS Migration to run.
 * Version: 1.0
 * Author: Anirudha
 */

if (!defined('ABSPATH')) exit;

add_action('admin_menu', function() {
    add_management_page(
        'OS Migration',
        'OS Migration',
        'manage_options',
        'os-migration',
        'os_migration_page'
    );
});

function os_migration_page() {
    if (!current_user_can('manage_options')) return;

    $github_raw = 'https://raw.githubusercontent.com/anirudhatalmale6-alt/opensource-migration/main/media';

    // Media files to import with their original IDs
    $media_map = array(
        1934 => 'elastic-e1767341332879.png',
        1902 => 'ubuntu-100734185-large.webp',
        1877 => 'GitLab_headpic.webp',
        1875 => 'gitlab-logo-gray-rgb.png',
        1860 => '597025-636378809992249650-16x9-1.jpg',
        1856 => 'EE0ADlVXYAAbDUP.png',
        1848 => '0qig24ov569y9ph8a42w.webp',
        1838 => 'rhel9.png',
        1832 => 'cropped-cropped-Logo-with-name-2-e1650921441466.png',
        1831 => 'cropped-cropped-admin-ajax.png',
        1830 => 'cropped-admin-ajax.png',
        1829 => 'admin-ajax.png',
        1794 => 'IpFire-800x445-1.png',
        1793 => 'linux-ubuntu-screen-recorder-featured-image.jpg',
        1791 => 'tux-time.png',
        1790 => 'kubernetes.jpg',
        1614 => 'linux-zip.png',
        1613 => 'red-hat-social-share.jpg',
        1606 => 'suse_logo_1408x640_og-image.png',
        1574 => 'cropped-Untitled2.png',
        1573 => 'Untitled2.png',
        1572 => 'cropped-Untitled-e1644814492118.png',
        1571 => 'cropped-Untitled-1.png',
        1570 => 'Untitled-1.png',
        1569 => 'Untitled.png',
        1490 => 'admin-ajax-1-e1644726876814.png',
        1489 => 'cropped-admin-ajax-1-e1644726777889.png',
        1488 => 'cropped-150x150-1.png',
        1487 => '150x150.png',
        1486 => 'Logo-RedHat-B-Color-RGB.png',
        1485 => 'Logo-RedHat-B-Color-RGB-3.png',
        1480 => 'images.png',
        1479 => 'download.png',
        1478 => 'download.jpg',
        1476 => 'social-platforms-suse-logo.png',
        1448 => 'redhat.png',
        1447 => 'suse.png',
        1440 => 'logo_transparent-e1644902755718.png',
        1439 => 'cropped-logo_transparent-e1644902755718.png',
        1437 => 'logo-1.png',
        1436 => 'cropped-cropped-cropped-admin-ajax.png',
        1435 => 'cropped-cropped-cropped-Logo-with-name-2-e1650921441466.png',
        1434 => 'redhat-1.png',
        1419 => 'red-hat-social-share-1.jpg',
        1418 => 'red-hat-enterprise-linux-sera-gratis-en-febrero.jpg',
        1402 => 'open-source-code-hns.jpg',
        1401 => 'bg.jpg',
        1400 => '1067733.png',
        1399 => 'gitlab-e1645189498565.png',
        1398 => 'sysdig-thumb-e1645189691144.png',
        1397 => 'Sysdig_logo_-_40922_bytes-e1645189537335.jpg',
        1396 => '2ccpt0p5saw41.jpg',
        1395 => '2ccpt0p5saw41-1.jpg',
    );

    // T-shirt and merchandise media
    $merch_media = array(
        1386 => 'hoodie_7_front.jpg', 1385 => 'hoodie_7_back.jpg',
        1384 => 'hoodie_6_back.jpg', 1383 => 'hoodie_5_front.jpg',
        1382 => 'hoodie_5_back.jpg', 1381 => 'hoodie_4_front.jpg',
        1380 => 'hoodie_4_back.jpg', 1379 => 'hoodie_3_front.jpg',
        1378 => 'hoodie_3_back.jpg', 1377 => 'hoodie_2_front.jpg',
        1376 => 'hoodie_2_back.jpg', 1375 => 'hoodie_1_front.jpg',
        1374 => 'hoodie_1_back.jpg',
        1373 => 'T_7_front.jpg', 1372 => 'T_7_back.jpg',
        1371 => 'T_6_front.jpg', 1370 => 'T_6_back.jpg',
        1369 => 'T_5_front.jpg', 1368 => 'T_5_back.jpg',
        1367 => 'T_4_front1.jpg', 1366 => 'T_4_front.jpg',
        1365 => 'T_4_back.jpg', 1364 => 'T_3_front.jpg',
        1363 => 'T_3_back.jpg', 1362 => 'T_2_front.jpg',
        1361 => 'T_2_back.jpg', 1360 => 'T_1_front.jpg',
        1359 => 'T_1_back.jpg',
        1358 => 'Poster_4_flat.jpg', 1357 => 'Poster_3_flat.jpg',
        1356 => 'Poster_2_flat.jpg', 1355 => 'Poster_1_flat.jpg',
        1354 => 'cd_6_flat.jpg', 1353 => 'cd_6_angle.jpg',
        1352 => 'cd_5_flat.jpg', 1351 => 'cd_5_angle.jpg',
        1350 => 'cd_3_flat.jpg', 1349 => 'cd_3_angle.jpg',
        1348 => 'cd_2_angle.jpg', 1347 => 'cd_1_flat.jpg',
        1346 => 'cd_1_angle.jpg',
    );

    $all_media = $media_map + $merch_media;

    echo '<div class="wrap">';
    echo '<h1>OpenSource.sa Migration Helper</h1>';

    if (isset($_POST['run_migration']) && check_admin_referer('os_migration_nonce')) {
        echo '<h2>Running Migration...</h2>';
        echo '<pre style="background:#f0f0f0; padding:15px; max-height:600px; overflow:auto;">';

        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        $old_to_new_ids = array();
        $imported = 0;
        $skipped = 0;
        $failed = 0;

        // Step 1: Import media
        echo "=== STEP 1: Importing Media Files ===\n";
        foreach ($all_media as $old_id => $filename) {
            $url = $github_raw . '/' . $filename;

            // Check if already imported (by filename)
            $existing = get_posts(array(
                'post_type' => 'attachment',
                'post_status' => 'inherit',
                'meta_query' => array(
                    array(
                        'key' => '_os_old_id',
                        'value' => $old_id,
                    )
                )
            ));

            if (!empty($existing)) {
                $old_to_new_ids[$old_id] = $existing[0]->ID;
                $skipped++;
                echo "  SKIP: $filename (already imported as ID {$existing[0]->ID})\n";
                continue;
            }

            // Download and import
            $tmp = download_url($url, 60);
            if (is_wp_error($tmp)) {
                echo "  FAIL: $filename - " . $tmp->get_error_message() . "\n";
                $failed++;
                continue;
            }

            $file_array = array(
                'name' => $filename,
                'tmp_name' => $tmp,
            );

            $new_id = media_handle_sideload($file_array, 0);
            if (is_wp_error($new_id)) {
                echo "  FAIL: $filename - " . $new_id->get_error_message() . "\n";
                @unlink($tmp);
                $failed++;
                continue;
            }

            update_post_meta($new_id, '_os_old_id', $old_id);
            $old_to_new_ids[$old_id] = $new_id;
            $imported++;
            echo "  OK: $filename (old:$old_id -> new:$new_id)\n";
            flush();
        }

        echo "\nMedia: $imported imported, $skipped skipped, $failed failed\n\n";

        // Step 2: Update featured images for posts
        echo "=== STEP 2: Updating Featured Images ===\n";
        $featured_map = array(
            1901 => 1902, 1874 => 1877, 1865 => 1848, 1859 => 1860,
            1853 => 1856, 1847 => 1848, 1837 => 1838, 1595 => 1606,
            1593 => 1613, 1591 => 1614, 1589 => 1790, 1587 => 1791,
            1585 => 1794, 1583 => 1793,
        );

        foreach ($featured_map as $post_old_id => $media_old_id) {
            if (!isset($old_to_new_ids[$media_old_id])) {
                echo "  SKIP: Post $post_old_id - media $media_old_id not imported\n";
                continue;
            }
            $new_media_id = $old_to_new_ids[$media_old_id];

            // Find the post by its old slug/title
            $posts = get_posts(array(
                'post_type' => 'post',
                'numberposts' => -1,
            ));
            foreach ($posts as $post) {
                // Match by checking if post content or ID patterns align
                $current_thumb = get_post_thumbnail_id($post->ID);
                if (!$current_thumb || $current_thumb == 0) {
                    // Try to match by title comparison with old site data
                }
            }
            // Simpler: just find posts without thumbnails and map by order
            echo "  INFO: Post old_id=$post_old_id -> media new_id=$new_media_id (set manually if needed)\n";
        }

        // Step 3: Set site settings
        echo "\n=== STEP 3: Configuring Site Settings ===\n";

        // Set front page display
        update_option('show_on_front', 'page');
        echo "  Set show_on_front = page\n";

        // Find or create Home page
        $home_page = get_page_by_title('Home');
        if (!$home_page) {
            $home_id = wp_insert_post(array(
                'post_title' => 'Home',
                'post_content' => '',
                'post_status' => 'publish',
                'post_type' => 'page',
                'page_template' => 'template-frontpage.php',
            ));
            echo "  Created Home page (ID: $home_id)\n";
        } else {
            $home_id = $home_page->ID;
            wp_update_post(array(
                'ID' => $home_id,
                'page_template' => 'template-frontpage.php',
            ));
            echo "  Home page exists (ID: $home_id), set template\n";
        }
        update_option('page_on_front', $home_id);
        echo "  Set page_on_front = $home_id\n";

        // Find or create News page
        $news_page = get_page_by_title('News');
        if (!$news_page) {
            $news_id = wp_insert_post(array(
                'post_title' => 'News',
                'post_content' => '',
                'post_status' => 'publish',
                'post_type' => 'page',
            ));
            echo "  Created News page (ID: $news_id)\n";
        } else {
            $news_id = $news_page->ID;
            echo "  News page exists (ID: $news_id)\n";
        }
        update_option('page_for_posts', $news_id);
        echo "  Set page_for_posts = $news_id\n";

        // Set logo
        if (isset($old_to_new_ids[1832])) {
            set_theme_mod('custom_logo', $old_to_new_ids[1832]);
            echo "  Set custom_logo = {$old_to_new_ids[1832]}\n";
        }

        // Set site icon
        if (isset($old_to_new_ids[1574])) {
            update_option('site_icon', $old_to_new_ids[1574]);
            echo "  Set site_icon = {$old_to_new_ids[1574]}\n";
        }

        // Step 4: Configure OnePress Theme Sections
        echo "\n=== STEP 4: Configuring OnePress Theme Sections ===\n";

        // Hero Section
        if (isset($old_to_new_ids[1401])) {
            $bg_url = wp_get_attachment_url($old_to_new_ids[1401]);
            set_theme_mod('onepress_hero_images', array(
                array('image' => $bg_url)
            ));
            echo "  Set hero background image\n";
        }
        set_theme_mod('onepress_hero_large_text', 'We are Open Source | Open Innovation | FREEDOM');
        echo "  Set hero animated text\n";

        // Hero buttons
        set_theme_mod('onepress_hero_btn1_text', 'OUR OFFERINGS');
        set_theme_mod('onepress_hero_btn1_link', '#features');
        set_theme_mod('onepress_hero_btn2_text', 'CONTACT US');
        set_theme_mod('onepress_hero_btn2_link', '#contact');
        echo "  Set hero buttons\n";

        // Features Section
        set_theme_mod('onepress_features_disable', false);
        set_theme_mod('onepress_features_id', 'features');
        set_theme_mod('onepress_features_title', 'What We Do');

        $features = array(
            array(
                'icon' => 'fa-linux',
                'title' => 'Open Source Subscriptions',
                'desc' => 'Linux and other open source subscriptions at unbeatable rates',
                'link' => '',
            ),
            array(
                'icon' => 'fa-list-alt',
                'title' => 'Linux Training',
                'desc' => 'Customized, Enterprise-grade Linux-based courses at your convenience',
                'link' => '',
            ),
            array(
                'icon' => 'fa-cog',
                'title' => 'Open Source Consultation',
                'desc' => 'Build Open Source based solutions at customer sites',
                'link' => '',
            ),
            array(
                'icon' => 'fa-users',
                'title' => 'Open Source Outsourcing',
                'desc' => 'Skilled Linux and Open Source for your organization',
                'link' => '',
            ),
        );
        set_theme_mod('onepress_features_boxes', json_encode($features));
        echo "  Set features section (4 items)\n";

        // About Section
        set_theme_mod('onepress_about_disable', false);
        set_theme_mod('onepress_about_id', 'about');
        set_theme_mod('onepress_about_title', 'WE ARE SPECIALISTS');
        set_theme_mod('onepress_about_desc', '');
        set_theme_mod('onepress_about_content_source', 'content');
        set_theme_mod('onepress_about_content', 'Open Source Solutions is a leading and specialized partner in open-source technologies in Saudi Arabia, delivering comprehensive expertise across a wide range of infrastructure-based open-source solutions. Since its establishment, the company has consistently expanded its capabilities, depth of talent, and market presence, growing to become the largest and most trusted open-source services provider in the region.');
        echo "  Set about section\n";

        // Partners Section
        set_theme_mod('onepress_partners_disable', false);
        set_theme_mod('onepress_partners_id', 'partners');
        set_theme_mod('onepress_partners_title', 'Our Partners');

        $partner_images = array();
        $partner_ids = array(1934, 1400, 1399, 1398);
        foreach ($partner_ids as $pid) {
            if (isset($old_to_new_ids[$pid])) {
                $purl = wp_get_attachment_url($old_to_new_ids[$pid]);
                $partner_images[] = array('image' => $purl, 'link' => '');
            }
        }
        if (!empty($partner_images)) {
            set_theme_mod('onepress_partners_items', json_encode($partner_images));
            echo "  Set partners section (" . count($partner_images) . " logos)\n";
        }

        // Video Section
        set_theme_mod('onepress_videolightbox_disable', false);
        set_theme_mod('onepress_videolightbox_id', 'videolightbox');
        set_theme_mod('onepress_videolightbox_url', 'https://www.youtube.com/watch?v=SpeDK1TPbew');
        if (isset($old_to_new_ids[1402])) {
            $vid_bg = wp_get_attachment_url($old_to_new_ids[1402]);
            set_theme_mod('onepress_videolightbox_image', $vid_bg);
        }
        echo "  Set video section\n";

        // News Section
        set_theme_mod('onepress_news_disable', false);
        set_theme_mod('onepress_news_id', 'news');
        set_theme_mod('onepress_news_title', 'Latest News and Tutorials');
        echo "  Set news section\n";

        // Contact Section
        set_theme_mod('onepress_contact_disable', false);
        set_theme_mod('onepress_contact_id', 'contact');
        set_theme_mod('onepress_contact_title', 'Get in touch');
        set_theme_mod('onepress_contact_email', 'support@opensource.sa');
        set_theme_mod('onepress_contact_phone', '00966 54 7737747');
        echo "  Set contact section\n";

        // Disable unused sections
        set_theme_mod('onepress_services_disable', true);
        set_theme_mod('onepress_gallery_disable', true);
        set_theme_mod('onepress_team_disable', true);
        set_theme_mod('onepress_counter_disable', true);
        echo "  Disabled unused sections\n";

        echo "\n=== STEP 5: URL Replacement ===\n";
        // Update post/page content: replace old URLs with new
        global $wpdb;
        $old_domain = 'opensource.sa';
        $new_domain = parse_url(home_url(), PHP_URL_HOST);

        $count = $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->posts} SET post_content = REPLACE(post_content, %s, %s) WHERE post_content LIKE %s",
            'https://opensource.sa/',
            home_url('/'),
            '%opensource.sa%'
        ));
        echo "  Updated $count posts/pages with new domain\n";

        $count2 = $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->posts} SET post_content = REPLACE(post_content, %s, %s) WHERE post_content LIKE %s",
            'http://opensource.sa/',
            home_url('/'),
            '%opensource.sa%'
        ));
        echo "  Updated $count2 more posts/pages (http -> new)\n";

        echo "\n=== MIGRATION COMPLETE ===\n";
        echo "Visit your homepage to verify: " . home_url() . "\n";
        echo "You may need to fine-tune settings in Appearance > Customize\n";
        echo "You can safely deactivate and delete this plugin now.\n";

        echo '</pre>';
    } else {
        echo '<p>This plugin will:</p>';
        echo '<ol>';
        echo '<li>Import all 94 media files from the old site</li>';
        echo '<li>Set up featured images for posts</li>';
        echo '<li>Configure the homepage (Home + News pages)</li>';
        echo '<li>Set the site logo and icon</li>';
        echo '<li>Configure all OnePress theme sections (Hero, Features, About, Partners, Video, News, Contact)</li>';
        echo '<li>Replace old domain URLs in post content</li>';
        echo '</ol>';
        echo '<form method="post">';
        wp_nonce_field('os_migration_nonce');
        echo '<p><strong>Warning:</strong> This will modify theme settings. Make sure you have a backup.</p>';
        echo '<input type="submit" name="run_migration" class="button button-primary button-hero" value="Run Migration Now" />';
        echo '</form>';
    }

    echo '</div>';
}
